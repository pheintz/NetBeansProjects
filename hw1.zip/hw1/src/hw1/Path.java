/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw1;

import java.util.Scanner;

/**
 * Path class which holds flight path information
 */
public class Path 
{
    String nextLoc;
    double bearing;
    double currLatRadians, currLongRadians;  //current radians
    double nextLatRadians, nextLongRadians;  //next location radians
    double nextLat, nextLong;                //next location lat/long values
    int numLocations;
    Scanner stdin = new Scanner(System.in);
    Path()
    {
        //constructor for navigation info
        numLocations = 0;
    }

    //adds a new location to the path
    void addLocation() 
    {
        /*
                case 1:
            cout << "Please enter the name of the next location: ";
            cin >> nextLoc;
            cout << "Please enter the latitude of the next location: ";
            cin >> nextLat;
            cout << "Please enter the longitude of the next location: ";
            cin >> nextLong;
            locationNames[numLocations] = nextLoc;
            locationLatitudes[numLocations] = nextLat;
            locationLongitudes[numLocations] = nextLong;
            ++numLocations;
            // start at first location
            if (numLocations == 1) {
                currLoc = nextLoc;
                currLocIndex = 0;
            }
            break;
        */
        System.out.println("Please enter the name of the next location: ");
        nextLoc = stdin.next();
        System.out.println("Please enter the latitude of the next location: ");
        nextLat = stdin.nextDouble();
        System.out.println("Please enter the latitude of the next location: ");
        nextLong = stdin.nextDouble();
    }
    
    //display the current path
    void displayPath() 
    {
    }
    
    //location we want to go to next
    void moveToLocation() 
    {
        System.out.println("Please enter the name of the location: ");
        nextLoc = stdin.next();
    }
    
    //inform the pilot what bearing to head out on
    int displayBearing() 
    {
        System.out.println("Head out on a bearing of " + bearing + " degrees.\n");
        return 0;
    } 
}
